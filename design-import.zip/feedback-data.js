/* Mock feedback data for the wexia Feedback admin prototype.
   Reports come from an in-app feedback module that lets users mark a spot
   on the page, write a comment, and submit. The module sends us:
   category, comment, page url, email, browser/os/viewport, a screenshot,
   and the coordinates of the marked area (marker, in % of the screenshot). */
(function () {
  const CATEGORIES = {
    bug:     { id: "bug",     label: "Bug",     hue: 26,  desc: "Nahlášené chyby" },
    feature: { id: "feature", label: "Feature", hue: 150, desc: "Návrhy funkcí" },
    design:  { id: "design",  label: "Design",  hue: 300, desc: "Designové podněty" },
    ux:      { id: "ux",      label: "UX",      hue: 235, desc: "Použitelnost" },
    text:    { id: "text",    label: "Text",    hue: 70,  desc: "Texty a překlepy" },
  };

  const STATUSES = {
    new:      { id: "new",      label: "Nový",      hue: 26 },
    progress: { id: "progress", label: "V řešení",  hue: 70 },
    resolved: { id: "resolved", label: "Vyřešeno",  hue: 150 },
    rejected: { id: "rejected", label: "Zamítnuto", hue: 0, muted: true },
  };

  // shorthand for building dates in June 2026
  const d = (day, h, m) => new Date(2026, 5, day, h, m).toISOString();

  const REPORTS = [
    {
      id: "FB-241", category: "bug", status: "new", priority: "high",
      email: "katzithebeast@gmail.com", url: "/app/inbox",
      title: "Tlačítko „Nový use case“ nereaguje na klik",
      comment: "Po prokliku z dashboardu do inboxu se tlačítko vpravo nahoře tváří aktivně, ale po kliknutí se vůbec nic nestane. Zkoušela jsem to dvakrát, console hází chybu.",
      createdAt: d(14, 19, 23),
      browser: "Chrome 126", os: "Windows 11", viewport: "1920×1080",
      page: "inbox",
      marker: { x: 71, y: 6, w: 16, h: 11 },
      notes: [],
    },
    {
      id: "FB-240", category: "bug", status: "new", priority: "med",
      email: "katzithebeast@gmail.com", url: "/app/inbox",
      title: "Statistické karty se překrývají na užším okně",
      comment: "Když zmenším okno, čísla v kartách přetečou přes sebe a poslední karta zmizí úplně mimo obrazovku.",
      createdAt: d(14, 19, 22),
      browser: "Chrome 126", os: "Windows 11", viewport: "1366×768",
      page: "inbox",
      marker: { x: 8, y: 30, w: 84, h: 22 },
      notes: [],
    },
    {
      id: "FB-238", category: "design", status: "new", priority: "low",
      email: "katzithebeast@gmail.com", url: "/app/usecases",
      title: "Kontrast textu na tmavém pozadí je nízký",
      comment: "Popisky use casů jsou skoro nečitelné, šedá na tmavě šedé. Šlo by to zesvětlit?",
      createdAt: d(12, 14, 3),
      browser: "Safari 17", os: "macOS 14", viewport: "1512×982",
      page: "usecases",
      marker: { x: 30, y: 42, w: 40, h: 10 },
      notes: [],
    },
    {
      id: "FB-235", category: "bug", status: "progress", priority: "high",
      email: "adela.knourkova@wexia.digital", url: "/app/usecases",
      title: "Filtr kategorií resetuje hledání",
      comment: "Když mám napsaný dotaz a kliknu na filtr kategorie, vyhledávací pole se vymaže a musím psát znovu.",
      createdAt: d(11, 9, 14),
      browser: "Firefox 127", os: "Windows 11", viewport: "1920×1080",
      page: "usecases",
      marker: { x: 4, y: 18, w: 30, h: 8 },
      notes: [
        { author: "Ty", at: d(11, 10, 2), text: "Reprodukováno, dávám do sprintu." },
      ],
    },
    {
      id: "FB-233", category: "feature", status: "new", priority: "med",
      email: "petr.novak@firma.cz", url: "/app/chat",
      title: "Export konverzace do PDF",
      comment: "Bylo by super umět konverzaci s asistentem stáhnout jako PDF, abych ji mohl poslat kolegům.",
      createdAt: d(11, 9, 12),
      browser: "Chrome 125", os: "Windows 10", viewport: "1600×900",
      page: "chat",
      marker: null,
      notes: [],
    },
    {
      id: "FB-231", category: "ux", status: "progress", priority: "med",
      email: "katzithebeast@gmail.com", url: "/app/usecases",
      title: "Není jasné, jak založit nový projekt",
      comment: "Hledala jsem tlačítko na nový projekt asi dvě minuty, je schované v menu. Chtělo by to viditelnější.",
      createdAt: d(11, 9, 11),
      browser: "Chrome 126", os: "macOS 14", viewport: "1440×900",
      page: "usecases",
      marker: { x: 76, y: 9, w: 18, h: 9 },
      notes: [
        { author: "Ty", at: d(11, 11, 30), text: "Souhlas, přidáme primární CTA do hlavičky." },
      ],
    },
    {
      id: "FB-229", category: "text", status: "resolved", priority: "low",
      email: "adela.knourkova@wexia.digital", url: "/app/settings",
      title: "Překlep v nastavení účtu",
      comment: "„Notifkace“ → „Notifikace“. Drobnost, ale bije do očí.",
      createdAt: d(10, 16, 41),
      browser: "Edge 126", os: "Windows 11", viewport: "1920×1080",
      page: "settings",
      marker: { x: 6, y: 36, w: 22, h: 6 },
      notes: [
        { author: "Ty", at: d(10, 17, 5), text: "Opraveno v buildu 2.4.1." },
      ],
    },
    {
      id: "FB-227", category: "bug", status: "new", priority: "high",
      email: "petr.novak@firma.cz", url: "/app/chat",
      title: "Odpověď asistenta se někdy nezobrazí celá",
      comment: "Dlouhá odpověď se utne v půlce a zbytek se objeví až po refreshi stránky.",
      createdAt: d(10, 13, 8),
      browser: "Chrome 126", os: "Windows 11", viewport: "1920×1080",
      page: "chat",
      marker: { x: 12, y: 55, w: 60, h: 20 },
      notes: [],
    },
    {
      id: "FB-224", category: "design", status: "progress", priority: "low",
      email: "katzithebeast@gmail.com", url: "/dashboard",
      title: "Ikony v sidebaru jsou nestejně velké",
      comment: "Některé ikony v levém menu vypadají větší než jiné, působí to neuspořádaně.",
      createdAt: d(9, 11, 20),
      browser: "Safari 17", os: "macOS 14", viewport: "1512×982",
      page: "dashboard",
      marker: { x: 1, y: 28, w: 14, h: 40 },
      notes: [],
    },
    {
      id: "FB-221", category: "bug", status: "resolved", priority: "med",
      email: "adela.knourkova@wexia.digital", url: "/app/inbox",
      title: "Datum u reportu je v budoucnosti",
      comment: "U některých záznamů svítí čas o hodinu napřed, nejspíš špatná časová zóna.",
      createdAt: d(8, 15, 2),
      browser: "Firefox 127", os: "Linux", viewport: "1920×1080",
      page: "inbox",
      marker: { x: 70, y: 20, w: 24, h: 6 },
      notes: [
        { author: "Ty", at: d(8, 16, 0), text: "Přešli jsme na UTC + lokální formát. Hotovo." },
      ],
    },
    {
      id: "FB-218", category: "feature", status: "new", priority: "low",
      email: "petr.novak@firma.cz", url: "/dashboard",
      title: "Dark/light přepínač podle systému",
      comment: "Chtělo by to možnost nechat téma řídit nastavením systému.",
      createdAt: d(8, 10, 47),
      browser: "Chrome 126", os: "macOS 14", viewport: "1440×900",
      page: "dashboard",
      marker: null,
      notes: [],
    },
    {
      id: "FB-215", category: "ux", status: "rejected", priority: "low",
      email: "katzithebeast@gmail.com", url: "/app/settings",
      title: "Příliš mnoho kroků při odhlášení",
      comment: "Odhlášení chce potvrzení ve dvou krocích, je to otravné.",
      createdAt: d(7, 18, 12),
      browser: "Chrome 125", os: "Windows 11", viewport: "1600×900",
      page: "settings",
      marker: { x: 4, y: 80, w: 20, h: 8 },
      notes: [
        { author: "Ty", at: d(7, 19, 0), text: "Dvojí potvrzení je záměrné kvůli bezpečnosti. Zamítám." },
      ],
    },
    {
      id: "FB-212", category: "bug", status: "progress", priority: "high",
      email: "adela.knourkova@wexia.digital", url: "/app/usecases",
      title: "Náhledy use casů se nenačtou na pomalém připojení",
      comment: "Na mobilních datech se obrázky netáhnou a zůstává prázdné místo bez placeholderu.",
      createdAt: d(6, 9, 33),
      browser: "Chrome 126", os: "Android 14", viewport: "412×915",
      page: "usecases",
      marker: { x: 8, y: 50, w: 40, h: 30 },
      notes: [],
    },
    {
      id: "FB-208", category: "text", status: "new", priority: "low",
      email: "petr.novak@firma.cz", url: "/app/chat",
      title: "Tlačítko „Odeslat“ vs. „Poslat“",
      comment: "Na různých místech appky je jednou „Odeslat“ a jinde „Poslat“. Sjednotit?",
      createdAt: d(5, 14, 22),
      browser: "Edge 126", os: "Windows 11", viewport: "1920×1080",
      page: "chat",
      marker: { x: 80, y: 84, w: 14, h: 8 },
      notes: [],
    },
    {
      id: "FB-205", category: "design", status: "resolved", priority: "med",
      email: "katzithebeast@gmail.com", url: "/dashboard",
      title: "Karty na dashboardu potřebují víc prostoru",
      comment: "Mezi kartami je málo místa, působí to nahuštěně. Víc vzduchu by pomohlo.",
      createdAt: d(4, 11, 5),
      browser: "Safari 17", os: "macOS 14", viewport: "1512×982",
      page: "dashboard",
      marker: { x: 6, y: 26, w: 88, h: 26 },
      notes: [
        { author: "Ty", at: d(4, 13, 0), text: "Zvětšili jsme gap a padding karet." },
      ],
    },
    {
      id: "FB-201", category: "bug", status: "rejected", priority: "low",
      email: "petr.novak@firma.cz", url: "/app/inbox",
      title: "Scrollbar je vidět i když není potřeba",
      comment: "Na Windows se zobrazuje šedý scrollbar i u krátkého obsahu.",
      createdAt: d(3, 16, 48),
      browser: "Chrome 125", os: "Windows 10", viewport: "1366×768",
      page: "inbox",
      marker: { x: 96, y: 10, w: 3, h: 70 },
      notes: [
        { author: "Ty", at: d(3, 17, 30), text: "Chování OS, neřešíme přepisem scrollbaru." },
      ],
    },
  ];

  // 14-day incoming trend (for the dashboard sparkline)
  const TREND = [2, 1, 3, 0, 4, 2, 5, 3, 1, 6, 4, 2, 7, 3];

  window.FB = { CATEGORIES, STATUSES, REPORTS, TREND };
})();
