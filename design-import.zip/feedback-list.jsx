/* Reports list view with search / sort / status filter. */
const { useState: useStateL, useEffect: useEffectL, useMemo: useMemoL } = React;

function ListRow({ r, onClick }) {
  const snippet = r.comment.length > 150 ? r.comment.slice(0, 150) + "…" : r.comment;
  return (
    <button className="list-row" onClick={onClick}>
      <div className="lr-thumb"><Thumb report={r} rounded={8} label={false} /></div>
      <div className="lr-main">
        <div className="lr-top">
          <CatBadge cat={r.category} />
          <span className="lr-id mono">{r.id}</span>
          <span className="lr-url mono"><Icon name="globe" size={12} />{r.url}</span>
        </div>
        <div className="lr-title">{r.title}</div>
        <div className="lr-snippet">{snippet}</div>
        <div className="lr-foot">
          <span className="lr-email"><Avatar email={r.email} size={20} /> {r.email}</span>
          <span className="lr-dot">·</span>
          <span className="lr-time"><Icon name="calendar" size={12} /> {fmtDate(r.createdAt)}</span>
        </div>
      </div>
      <div className="lr-side">
        <StatusPill status={r.status} />
        <span className="lr-ago">{timeAgo(r.createdAt)}</span>
        <Icon name="chevronRight" size={18} className="lr-chev" />
      </div>
    </button>
  );
}

function ReportList({ reports, nav, go, openReport }) {
  const { STATUSES, CATEGORIES } = window.FB;
  const [q, setQ] = useStateL("");
  const [sort, setSort] = useStateL("newest");
  const [statusF, setStatusF] = useStateL("all");

  useEffectL(() => {
    setStatusF(nav.kind === "status" ? nav.value : "all");
    setQ("");
  }, [nav.kind, nav.value]);

  const base = useMemoL(() => {
    let list = reports;
    if (nav.kind === "category") list = list.filter((r) => r.category === nav.value);
    return list;
  }, [reports, nav.kind, nav.value]);

  const filtered = useMemoL(() => {
    let list = base;
    if (statusF !== "all") list = list.filter((r) => r.status === statusF);
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter((r) => (r.title + r.comment + r.email + r.url).toLowerCase().includes(t));
    }
    list = [...list].sort((a, b) => sort === "newest"
      ? new Date(b.createdAt) - new Date(a.createdAt)
      : new Date(a.createdAt) - new Date(b.createdAt));
    return list;
  }, [base, statusF, q, sort]);

  let heading = "Všechny reporty", sub = "Kompletní zpětná vazba";
  if (nav.kind === "status") { heading = STATUSES[nav.value].label; sub = "Reporty se stavem „" + STATUSES[nav.value].label.toLowerCase() + "“"; }
  if (nav.kind === "category") { heading = CATEGORIES[nav.value].label; sub = CATEGORIES[nav.value].desc; }

  const statusChips = ["all", "new", "progress", "resolved", "rejected"];

  return (
    <div className="view list">
      <header className="view-head">
        <div>
          <h1>{heading}</h1>
          <p>{sub}</p>
        </div>
        <div className="head-badge"><Icon name="layers" size={15} /> {filtered.length} z {base.length}</div>
      </header>

      <div className="toolbar">
        <div className="search">
          <Icon name="search" size={17} />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Hledat v komentáři, e-mailu nebo URL…" />
          {q && <button className="search-clear" onClick={() => setQ("")}><Icon name="x" size={14} /></button>}
        </div>
        <div className="sort">
          <Icon name="trend" size={15} />
          <select value={sort} onChange={(e) => setSort(e.target.value)}>
            <option value="newest">Nejnovější</option>
            <option value="oldest">Nejstarší</option>
          </select>
          <Icon name="chevronDown" size={14} className="sort-chev" />
        </div>
      </div>

      {nav.kind !== "status" && (
        <div className="chips">
          {statusChips.map((s) => (
            <button key={s} className={"chip" + (statusF === s ? " on" : "")}
              style={s !== "all" && !STATUSES[s].muted ? { "--h": STATUSES[s].hue } : undefined}
              onClick={() => setStatusF(s)}>
              {s !== "all" && <span className="chip-dot" style={{ "--h": STATUSES[s]?.hue ?? 0 }} />}
              {s === "all" ? "Vše" : STATUSES[s].label}
              <span className="chip-n">{s === "all" ? base.length : base.filter((r) => r.status === s).length}</span>
            </button>
          ))}
        </div>
      )}

      <div className="rows">
        {filtered.length === 0 && (
          <div className="empty"><Icon name="inbox" size={28} /><div>Nic tu není</div><p>Zkus změnit filtr nebo hledaný výraz.</p></div>
        )}
        {filtered.map((r) => <ListRow key={r.id} r={r} onClick={() => openReport(r.id)} />)}
      </div>
    </div>
  );
}

Object.assign(window, { ReportList, ListRow });
