/* App shell, routing, state. */
const { useState: useStateA, useEffect: useEffectA } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "#e23b2e",
  "density": "vzdušné",
  "thumbs": true
}/*EDITMODE-END*/;

function App() {
  const [reports, setReports] = useStateA(window.FB.REPORTS);
  const [nav, setNav] = useStateA({ view: "dashboard" });
  const [selId, setSelId] = useStateA(null);
  const [theme, setTheme] = useStateA(() => localStorage.getItem("wexia-fb-theme") || "dark");
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  useEffectA(() => {
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("wexia-fb-theme", theme);
  }, [theme]);

  useEffectA(() => {
    const r = document.documentElement, s = r.style;
    s.setProperty("--accent", t.accent);
    s.setProperty("--accent-hi", `color-mix(in oklch, ${t.accent}, white 14%)`);
    s.setProperty("--accent-soft", `color-mix(in oklch, ${t.accent} 14%, transparent)`);
    s.setProperty("--accent-line", `color-mix(in oklch, ${t.accent} 32%, transparent)`);
    r.classList.toggle("compact", t.density === "kompaktní");
    r.classList.toggle("no-thumbs", !t.thumbs);
  }, [t.accent, t.density, t.thumbs]);

  const go = (n) => { setSelId(null); setNav(n); window.scrollTo(0, 0); document.querySelector(".main")?.scrollTo(0, 0); };
  const openReport = (id) => { setSelId(id); setNav((p) => ({ ...p, view: "detail" })); document.querySelector(".main")?.scrollTo(0, 0); };
  const onStatus = (id, status) => setReports((rs) => rs.map((r) => r.id === id ? { ...r, status } : r));
  const onAddNote = (id, text) => setReports((rs) => rs.map((r) => r.id === id
    ? { ...r, notes: [...r.notes, { author: "Ty", at: new Date().toISOString(), text }] } : r));

  const selected = reports.find((r) => r.id === selId);

  return (
    <div className="app">
      <Sidebar reports={reports} nav={nav} go={go} theme={theme} toggleTheme={() => setTheme((t) => t === "dark" ? "light" : "dark")} />
      <main className="main">
        <div className="main-inner">
          {nav.view === "dashboard" && <Dashboard reports={reports} go={go} openReport={openReport} />}
          {nav.view === "list" && <ReportList reports={reports} nav={nav} go={go} openReport={openReport} />}
          {nav.view === "detail" && selected && (
            <ReportDetail report={selected} reports={reports} go={go} openReport={openReport} onStatus={onStatus} onAddNote={onAddNote} />
          )}
        </div>
      </main>
      <TweaksPanel title="Tweaks">
        <TweakSection label="Vzhled" />
        <TweakColor label="Akcent" value={t.accent}
          options={["#e23b2e", "#3b6fe2", "#1f9d6b", "#7a5ae0", "#e0902a"]}
          onChange={(v) => setTweak("accent", v)} />
        <TweakRadio label="Hustota" value={t.density}
          options={["vzdušné", "kompaktní"]}
          onChange={(v) => setTweak("density", v)} />
        <TweakToggle label="Náhledy v seznamu" value={t.thumbs}
          onChange={(v) => setTweak("thumbs", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
