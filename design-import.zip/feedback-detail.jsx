/* Report detail view. */
const { useState: useStateD } = React;

function MetaItem({ icon, label, value, mono }) {
  return (
    <div className="meta-item">
      <span className="meta-ic"><Icon name={icon} size={15} /></span>
      <div>
        <div className="meta-label">{label}</div>
        <div className={"meta-value" + (mono ? " mono" : "")}>{value}</div>
      </div>
    </div>
  );
}

function ReportDetail({ report, reports, go, openReport, onStatus, onAddNote }) {
  const [draft, setDraft] = useStateD("");
  const { STATUSES, CATEGORIES } = window.FB;

  const sorted = [...reports].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const idx = sorted.findIndex((r) => r.id === report.id);
  const prev = sorted[idx - 1], next = sorted[idx + 1];

  const submit = () => { if (draft.trim()) { onAddNote(report.id, draft.trim()); setDraft(""); } };

  return (
    <div className="view detail">
      <div className="detail-bar">
        <button className="back-btn" onClick={() => go({ view: "list", kind: "all" })}>
          <Icon name="arrowLeft" size={16} /> Zpět na reporty
        </button>
        <div className="detail-nav">
          <button disabled={!prev} onClick={() => prev && openReport(prev.id)} title="Novější"><Icon name="chevronDown" size={16} style={{ transform: "rotate(90deg)" }} /></button>
          <span className="mono">{report.id}</span>
          <button disabled={!next} onClick={() => next && openReport(next.id)} title="Starší"><Icon name="chevronDown" size={16} style={{ transform: "rotate(-90deg)" }} /></button>
        </div>
      </div>

      <div className="detail-grid">
        <div className="detail-main">
          <div className="detail-titlerow">
            <CatBadge cat={report.category} />
            <StatusPill status={report.status} />
            {report.priority === "high" && <span className="prio"><Icon name="flag" size={12} /> Priorita</span>}
          </div>
          <h1 className="detail-title">{report.title}</h1>

          <div className="shot">
            <Thumb report={report} rounded={14} />
            <div className="shot-cap"><Icon name="pin" size={13} /> Uživatelem označené místo na stránce <span className="mono">{report.url}</span></div>
          </div>

          <div className="comment-block">
            <div className="cb-head"><Icon name="comment" size={15} /> Komentář uživatele</div>
            <p>{report.comment}</p>
          </div>

          <div className="meta-grid">
            <MetaItem icon="mail" label="E-mail" value={report.email} mono />
            <MetaItem icon="globe" label="Stránka" value={report.url} mono />
            <MetaItem icon="monitor" label="Prohlížeč" value={report.browser} />
            <MetaItem icon="layers" label="Systém" value={report.os} />
            <MetaItem icon="dashboard" label="Rozlišení" value={report.viewport} mono />
            <MetaItem icon="calendar" label="Přijato" value={fmtDate(report.createdAt)} />
          </div>
        </div>

        <aside className="detail-side">
          <div className="side-card">
            <div className="side-title">Změnit stav</div>
            <div className="status-options">
              {["new", "progress", "resolved", "rejected"].map((s) => (
                <button key={s} className={"status-opt" + (report.status === s ? " on" : "")}
                  style={!STATUSES[s].muted ? { "--h": STATUSES[s].hue } : undefined}
                  onClick={() => onStatus(report.id, s)}>
                  <Icon name={STATUS_ICON[s]} size={15} />
                  {STATUSES[s].label}
                  {report.status === s && <Icon name="check" size={14} className="opt-check" />}
                </button>
              ))}
            </div>
          </div>

          <div className="side-card">
            <div className="side-title">Vlastnosti</div>
            <div className="prop-row"><span>Kategorie</span><CatBadge cat={report.category} size="sm" /></div>
            <div className="prop-row"><span>Priorita</span>
              <span className={"prio-tag " + report.priority}>{report.priority === "high" ? "Vysoká" : report.priority === "med" ? "Střední" : "Nízká"}</span>
            </div>
            <div className="prop-row"><span>ID reportu</span><span className="mono">{report.id}</span></div>
          </div>

          <div className="side-card">
            <div className="side-title">Interní poznámky</div>
            <div className="notes">
              {report.notes.length === 0 && <div className="notes-empty">Zatím žádné poznámky.</div>}
              {report.notes.map((nn, i) => (
                <div className="note" key={i}>
                  <div className="note-head"><Avatar email={nn.author} size={20} /><strong>{nn.author}</strong><span>{timeAgo(nn.at)}</span></div>
                  <p>{nn.text}</p>
                </div>
              ))}
            </div>
            <div className="note-add">
              <textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Přidat poznámku k řešení…"
                onKeyDown={(e) => { if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) submit(); }} />
              <button className="btn-primary" disabled={!draft.trim()} onClick={submit}><Icon name="plus" size={15} /> Přidat poznámku</button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

Object.assign(window, { ReportDetail });
