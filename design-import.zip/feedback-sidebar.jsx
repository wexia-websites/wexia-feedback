/* Sidebar navigation. */

function NavItem({ icon, label, count, active, accent, onClick, hue }) {
  return (
    <button className={"nav-item" + (active ? " active" : "") + (accent ? " accent" : "")}
      style={hue != null ? { "--h": hue } : undefined} onClick={onClick}>
      <span className="nav-icon">{typeof icon === "string" ? <Icon name={icon} size={18} /> : icon}</span>
      <span className="nav-label">{label}</span>
      {count != null && count > 0 && <span className="nav-count">{count}</span>}
    </button>
  );
}

function Sidebar({ reports, nav, go, theme, toggleTheme }) {
  const { STATUSES, CATEGORIES } = window.FB;
  const countStatus = (s) => reports.filter((r) => r.status === s).length;
  const countCat = (c) => reports.filter((r) => r.category === c).length;

  const isStatus = (s) => nav.view === "list" && nav.kind === "status" && nav.value === s;
  const isCat = (c) => nav.view === "list" && nav.kind === "category" && nav.value === c;

  const statusOrder = ["new", "progress", "resolved", "rejected"];
  const catOrder = ["bug", "feature", "design", "ux", "text"];

  return (
    <aside className="sidebar">
      <div className="brand">
        <div className="brand-mark"><span>w</span></div>
        <div className="brand-text">
          <div className="brand-name">Feedback</div>
          <div className="brand-sub">AI Laboratoř · wexia</div>
        </div>
      </div>

      <div className="nav-scroll">
        <nav className="nav-group">
          <NavItem icon="dashboard" label="Přehled"
            active={nav.view === "dashboard"} onClick={() => go({ view: "dashboard" })} />
        </nav>

        <div className="nav-heading">Stav</div>
        <nav className="nav-group">
          {statusOrder.map((s) => (
            <NavItem key={s} icon={STATUS_ICON[s]} label={STATUSES[s].label}
              count={countStatus(s)} hue={STATUSES[s].muted ? null : STATUSES[s].hue}
              active={isStatus(s)} onClick={() => go({ view: "list", kind: "status", value: s })} />
          ))}
        </nav>

        <div className="nav-heading">Kategorie</div>
        <nav className="nav-group">
          {catOrder.map((c) => (
            <NavItem key={c} icon={CAT_ICON[c]} label={CATEGORIES[c].label}
              count={countCat(c)} hue={CATEGORIES[c].hue}
              active={isCat(c)} onClick={() => go({ view: "list", kind: "category", value: c })} />
          ))}
        </nav>
      </div>

      <div className="sidebar-footer">
        <button className="nav-item ghost" onClick={toggleTheme}>
          <span className="nav-icon"><Icon name={theme === "dark" ? "sun" : "moon"} size={18} /></span>
          <span className="nav-label">{theme === "dark" ? "Světlý režim" : "Tmavý režim"}</span>
        </button>
        <button className="nav-item ghost">
          <span className="nav-icon"><Icon name="logout" size={18} /></span>
          <span className="nav-label">Odhlásit</span>
        </button>
      </div>
    </aside>
  );
}

Object.assign(window, { Sidebar, NavItem });
