/* Dashboard / Přehled view. */

function StatCard({ label, value, sub, hue, accent, icon, onClick }) {
  return (
    <button className={"stat-card" + (accent ? " accent" : "")} style={hue != null ? { "--h": hue } : undefined} onClick={onClick}>
      <div className="stat-top">
        <span className="stat-label">{label}</span>
        <span className="stat-icon"><Icon name={icon} size={16} /></span>
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-sub">{sub}</div>
    </button>
  );
}

function TrendChart({ data }) {
  const max = Math.max(...data, 1);
  const total = data.reduce((a, b) => a + b, 0);
  return (
    <div className="card chart-card">
      <div className="card-head">
        <div>
          <div className="card-title">Příchozí reporty</div>
          <div className="card-sub">Posledních 14 dní</div>
        </div>
        <div className="chart-total">{total}<span>celkem</span></div>
      </div>
      <div className="bars">
        {data.map((v, i) => (
          <div className="bar-col" key={i}>
            <div className="bar" style={{ height: (v / max) * 100 + "%" }} data-v={v}>
              <span className="bar-val">{v}</span>
            </div>
          </div>
        ))}
      </div>
      <div className="bars-axis"><span>−14 d</span><span>dnes</span></div>
    </div>
  );
}

function CategoryBreakdown({ reports, go }) {
  const { CATEGORIES } = window.FB;
  const order = ["bug", "feature", "design", "ux", "text"];
  const counts = order.map((c) => ({ c, n: reports.filter((r) => r.category === c).length }));
  const max = Math.max(...counts.map((x) => x.n), 1);
  return (
    <div className="card">
      <div className="card-head">
        <div><div className="card-title">Podle kategorie</div><div className="card-sub">Rozdělení všech reportů</div></div>
      </div>
      <div className="breakdown">
        {counts.map(({ c, n }) => (
          <button className="bd-row" key={c} style={{ "--h": CATEGORIES[c].hue }} onClick={() => go({ view: "list", kind: "category", value: c })}>
            <span className="bd-icon"><Icon name={CAT_ICON[c]} size={15} /></span>
            <span className="bd-label">{CATEGORIES[c].label}</span>
            <span className="bd-track"><span className="bd-fill" style={{ width: (n / max) * 100 + "%" }} /></span>
            <span className="bd-count">{n}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function RecentRow({ r, onClick }) {
  return (
    <button className="recent-row" onClick={onClick}>
      <span className="rr-cat" style={{ "--h": window.FB.CATEGORIES[r.category].hue }}><Icon name={CAT_ICON[r.category]} size={15} /></span>
      <span className="rr-body">
        <span className="rr-title">{r.title}</span>
        <span className="rr-meta"><span className="mono">{r.url}</span> · {timeAgo(r.createdAt)}</span>
      </span>
      <StatusPill status={r.status} />
      <Icon name="chevronRight" size={16} className="rr-chev" />
    </button>
  );
}

function Dashboard({ reports, go, openReport }) {
  const { STATUSES } = window.FB;
  const n = (s) => reports.filter((r) => r.status === s).length;
  const recent = [...reports].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 5);

  return (
    <div className="view dash">
      <header className="view-head">
        <div>
          <h1>Přehled</h1>
          <p>Zpětná vazba z AI Laboratoře — co přišlo a kde to vázne.</p>
        </div>
        <div className="head-badge"><Icon name="layers" size={15} /> {reports.length} reportů</div>
      </header>

      <div className="stat-grid">
        <StatCard label="Nové" value={n("new")} sub="čeká na zpracování" hue={STATUSES.new.hue} accent icon="inbox"
          onClick={() => go({ view: "list", kind: "status", value: "new" })} />
        <StatCard label="V řešení" value={n("progress")} sub="právě opravujeme" hue={STATUSES.progress.hue} icon="progress"
          onClick={() => go({ view: "list", kind: "status", value: "progress" })} />
        <StatCard label="Vyřešeno" value={n("resolved")} sub="hotovo" hue={STATUSES.resolved.hue} icon="check"
          onClick={() => go({ view: "list", kind: "status", value: "resolved" })} />
        <StatCard label="Zamítnuto" value={n("rejected")} sub="nebudeme řešit" hue={null} icon="x"
          onClick={() => go({ view: "list", kind: "status", value: "rejected" })} />
      </div>

      <div className="dash-cols">
        <TrendChart data={window.FB.TREND} />
        <CategoryBreakdown reports={reports} go={go} />
      </div>

      <div className="card recent-card">
        <div className="card-head">
          <div><div className="card-title">Nejnovější reporty</div><div className="card-sub">Poslední příchozí zpětná vazba</div></div>
          <button className="link-btn" onClick={() => go({ view: "list", kind: "all" })}>Zobrazit vše <Icon name="arrowUpRight" size={14} /></button>
        </div>
        <div className="recent-list">
          {recent.map((r) => <RecentRow key={r.id} r={r} onClick={() => openReport(r.id)} />)}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { Dashboard, StatCard, TrendChart, CategoryBreakdown, RecentRow });
